<?php 
    session_start();
    include '../../linkdb.php';
    $url = $_POST['url'];
    $imgname = $_POST['imgname'];
    $username = $_SESSION['username'];
    $prepare = $mysqli ->prepare("INSERT INTO `imginfo`(`username`,`img`,`imgname`) VALUE(?,?,?)");
    $prepare ->bind_param("sss",$username,$url,$imgname);
    $prepare ->execute();
    $prepare ->close();
?>
