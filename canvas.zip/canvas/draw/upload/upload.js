var submitButton = document.getElementById("submit");
var canvas = document.getElementById("mycanvas");

submitButton.addEventListener("click",submit);

function submit(){
    var URL = canvas.toDataURL();
    var imgname = document.getElementById("imgname").value;
    var data = {};
    data['url'] = URL ;
    data['imgname'] = imgname;
    $.ajax({
        type: "POST",
        url: "upload/upload.php",
        data: data ,
        success :function(){
            alert("作品上传成功!");
            window.location.reload();
        }
    })
}

