var canvas = document.getElementById("mycanvas");
var context = canvas.getContext("2d");
var canvasName = canvas.name;
var button = document.getElementById("pattern");
var area = document.getElementsByTagName("area");
var color = "#FFFFFF";
var bgcolor = "#FFFFFF"
bgc();
color = "#000000"
var chosecolor = document.getElementById("chosecolor");
canvasName = "draw";

for(let i =0;i<area.length;i++){
    area[i].addEventListener("click",function(){
        color = area[i].alt;
        chosecolor.style.backgroundColor = color;
    })
}

function changePattern() {
    canvasName == "draw" ? (canvasName = "redraw", button.innerText = "橡皮擦") : (canvasName = "draw", button.innerText = "画笔");
}
function bgc(){
    bgcolor = color ;
    context.fillStyle=bgcolor;
    context.fillRect(0,0,1000,500);
}
function paint(event) {
    var box = canvas.getBoundingClientRect();
    var x = parseInt(event.clientX - box.left);
    x = x - x % 6;
    //保证x坐标是6的倍数
    var y = parseInt(event.clientY - box.top);
    y = y - y % 6;
    //保证y坐标是6的倍数
    if (canvasName == "draw") {
        context.fillStyle = color ;
        context.fillRect(x - 1, y - 1, 6, 6);
    }
    else {
        context.fillStyle = bgcolor;
        context.fillRect(x - 1, y - 1, 6, 6);
    }
}  