<?php 
    $servername = "localhost" ;
    $user = "TearsJin" ;
    $pass = "wdnmd666";
    $dbname = "2020";
    $mysqli = new mysqli($servername,$user,$pass,$dbname);
    if($mysqli -> connect_error){
        die("连接失败: ".$mysqli->connect_error);
    }else{
        // echo "hello!";
    }
?>