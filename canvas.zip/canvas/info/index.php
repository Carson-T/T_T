<?php
session_start();
if (empty($_GET['username'])) {
    echo <<<EOF
                <script>
                    window.alert('请先登录');
                    location.href='../login';
                </script>
EOF;
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>个人信息</title>
    <link rel="stylesheet" href="css/info.css">
</head>

<body>
    <h1>
        <a href="../draw">画布</a>
        <a href="../">首页</a>
        <a href="../display">展示</a>
    </h1>

    <?php
    include "../linkdb.php";
    $username = $_GET['username'];
    $prepare = $mysqli->prepare("SELECT * FROM `userinfo` WHERE `username` = ?");
    $prepare->bind_param("s", $username);
    $prepare->execute();
    $result = $prepare->get_result();
    $result = $result->fetch_all(MYSQLI_ASSOC);
    $prepare->close();
    $id = $result[0]['id'];
    $username = $result[0]['username'];
    $photo = "https://s2.ax1x.com/2020/02/02/1YCFdH.jpg";
    if ($result[0]['photo'] !== NULL) {
        $photo = $result[0]['photo'];
    }
    $profile = $result[0]['profile'];
    echo <<<EOF
            <div id="contenter">
                <div id="photo">
                    <p><img src="$photo"></p>
                    <p>用户id:$id</p>
                    <p>用户名:$username</p>
                    <a href="logout.php">注销</a>
                </div>
                <div id="profile">
                    <div style="height:100px;">
                    <p>个人简介:</p>
                    <p id="profileText">$profile</p>
EOF;
    if ($_SESSION['username'] === $_GET['username']) {
        echo <<<EOF
            <button id="proChange">修改简介</button>
            <script src="js/info.js"></script>
EOF;
    }
    $prepare = $mysqli->prepare("SELECT * FROM `imginfo` WHERE `username`= ? LIMIT 10" );
    $prepare->bind_param("s", $username);
    $prepare->execute();
    $result = $prepare->get_result();
    $result = $result->fetch_all(MYSQLI_ASSOC);
    $prepare->close();
    echo <<<EOF
    </div>
    <div style="width:600px">
        <p>作品:</p>
EOF;
    foreach ($result as $value) {
        $img = $value['img'];
        $imgid = $value['imgid'];
        $imgname = $value['imgname'];
        echo <<<EOF
            <div  style="float:left">
            <a href="../solo?imgid=$imgid"><img src="$img" style="margin:5px;"></a>
            <p style="text-align:center;">$imgname</p>
            </div>
EOF;
    }
    echo <<<EOF
    </div>
    </div>
    </div>
EOF;
    ?>
</body>

</html>