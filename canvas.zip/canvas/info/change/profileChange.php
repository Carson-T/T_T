<?php
    session_start();
    if(empty($_SESSION['username'])){
        header("location:../../index");
    }
    include "../../linkdb.php";
    $profile = htmlspecialchars($_POST['changeProflie']);
    $username = $_SESSION['username'];
    $prepare = $mysqli ->prepare("UPDATE `userinfo` SET `profile` = ? WHERE `username` = ?");
    $prepare ->bind_param("ss",$profile,$username);
    $prepare ->execute();
    $prepare ->close();
    echo <<<EOF
            <script>
                alert("修改成功");
                window.location.href='../../info?username=$username';
            </script>
EOF;
    ?>