var changeButton = document.getElementById("proChange");
changeButton.addEventListener("click", function () {
    if (changeButton.innerText=="放弃修改") {
        var changeHTML = document.getElementById("text").innerHTML;
        var input = document.getElementById("profileText");
        input.innerHTML = changeHTML ;
        changeButton.innerText = "修改简介";
    } else {
        var input = document.getElementById("profileText");
        var changeHTML = '<form action="change/profileChange.php" method="POST">' + '<textarea id="text" type="text" name="changeProflie">' + input.innerHTML + '</textarea><input type="submit" value="提交">' + '</form>'
        input.innerHTML = changeHTML;
        changeButton.innerText = "放弃修改";
    }
})