<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>像素点画布</title>
  <link rel="stylesheet" href="css/index.css">

</head>

<body>

  <h1>
    <a href="draw">画布</a>
    <?php
      session_start();
      $username = $_SESSION['username'];
      echo <<<EOF
      <a href="info?username=$username">个人</a>
EOF 
  ?>
    <a href="">首页</a>
    <a href="login">登陆</a>
    <a href="display">展示</a>
  </h1>
  <div id="particles-js" style="display: flex;align-items: center;justify-content: center">
  </div>
  <script src="js/particles.js"></script>
  <script src="js/app.js"></script>
  <script>
    function changeImg() {
      let pic = document.getElementById('picture');
      console.log(pic.src)
      if (pic.getAttribute("src", 2) == "img/check.png") {
        pic.src = "img/checked.png"
      } else {
        pic.src = "img/check.png"
      }
    }
  </script>
</body>
