<?php
	session_start();
	if(!empty($_SESSION['username'])){
		$username= $_SESSION['username'];
		header("location:../info?username=$username");
	}
?> 

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport"
		content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="description" content="particles.js is a lightweight JavaScript library for creating particles.">
	<title>登录</title>
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/login.css">
	<link rel="stylesheet" href="css/sign-up-login.css">
	<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/inputEffect.css" />
	<link rel="stylesheet" href="css/tooltips.css" />
	<link rel="stylesheet" href="css/spop.min.css" />
	<div id="particles-js" style="display: flex;align-items: center;justify-content: center">
	</div>
	<script src="../js/jquery.min.js"></script>
	<script src="js/snow.js"></script>
	<script src="js/jquery.pure.tooltips.js"></script>
	<script src="js/spop.min.js"></script>
	<script src="js/particles.js"></script>
	<script>
		(function () {
			if (!String.prototype.trim) {
				(function () {
					// Make sure we trim BOM and NBSP
					var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
					String.prototype.trim = function () {
						return this.replace(rtrim, '');
					};
				})();
			}

			[].slice.call(document.querySelectorAll('input.input__field')).forEach(function (inputEl) {
				// in case the input is already filled..
				if (inputEl.value.trim() !== '') {
					classie.add(inputEl.parentNode, 'input--filled');
				}

				// events:
				inputEl.addEventListener('focus', onInputFocus);
				inputEl.addEventListener('blur', onInputBlur);
			});

			function onInputFocus(ev) {
				classie.add(ev.target.parentNode, 'input--filled');
			}

			function onInputBlur(ev) {
				if (ev.target.value.trim() === '') {
					classie.remove(ev.target.parentNode, 'input--filled');
				}
			}
		})();

		$(function () {
			$('#login #login-password').focus(function () {
				$('.login-owl').addClass('password');
			}).blur(function () {
				$('.login-owl').removeClass('password');
			});
			$('#login #register-password').focus(function () {
				$('.register-owl').addClass('password');
			}).blur(function () {
				$('.register-owl').removeClass('password');
			});
			$('#login #register-repassword').focus(function () {
				$('.register-owl').addClass('password');
			}).blur(function () {
				$('.register-owl').removeClass('password');
			});
		});

		function goto_register() {
			$("#register-username").val("");
			$("#register-password").val("");
			$("#register-repassword").val("");
			$("#register-code").val("");
			$("#tab-2").prop("checked", true);
		}

		function goto_login() {
			$("#login-username").val("");
			$("#login-password").val("");
			$("#tab-1").prop("checked", true);
		}
	</script>
	<style type="text/css">
		body {
			background-repeat: no-repeat;
			background-position: center center #2D0F0F;
			background-color: black;
			background-image: url(https://s2.ax1x.com/2020/01/23/1VK0xJ.png);
			background-size: cover;
		}
		a:link {
			color: #ffffff;
		}

		/* 未访问链接*/
		a:visited {
			color: #ffffff;
		}

		/* 已访问链接 */
		a:hover {
			color: #8585e0;
		}

		/* 鼠标移动到链接上 */
		a:active {
			color: #b3d9ff;
		}

		/* 鼠标点击时 */
		a {
			TEXT-DECORATION: none
		}

		.snow-container {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			pointer-events: none;
			z-index: 100001;
		}
	</style>
</head>

<body>
	<!-- 雪花背景 -->
	<div class="snow-container"></div>
	<!-- 登录控件 -->
	<div id="login" style="margin-top:100px ;">
		<input id="tab-1" type="radio" name="tab" class="sign-in hidden" checked />
		<input id="tab-2" type="radio" name="tab" class="sign-up hidden" />
		<input id="tab-3" type="radio" name="tab" class="sign-out hidden" />
		<div class="wrapper">
			<!-- 登录页面 -->
			<div class="login sign-in-htm">
				<form class="container offset1 loginform" action="logOrRig.php" method="POST">
					<!-- 猫头鹰控件 -->
					<div id="owl-login" class="login-owl">
						<div class="hand"></div>
						<div class="hand hand-r"></div>
						<div class="arms">
							<div class="arm"></div>
							<div class="arm arm-r"></div>
						</div>
					</div>
					<div class="pad input-container">
						<section class="content">
							<span class="input input--hideo">
								<input class="input__field input__field--hideo" type="text" id="login-username"
									autocomplete="off" placeholder="请输入用户名" tabindex="1" maxlength="15" name="username"/>
								<label class="input__label input__label--hideo" for="login-username">
									<i class="fa fa-fw fa-user icon icon--hideo"></i>
									<span class="input__label-content input__label-content--hideo"></span>
								</label>
							</span>
							<span class="input input--hideo">
								<input class="input__field input__field--hideo" type="password" id="login-password"
									placeholder="请输入密码" tabindex="2" maxlength="15" name="password"/>
								<label class="input__label input__label--hideo" for="login-password">
									<i class="fa fa-fw fa-lock icon icon--hideo"></i>
									<span class="input__label-content input__label-content--hideo"></span>
								</label>
							</span>
						</section>
					</div>
					<div class="form-actions">
						<input type="hidden" name="flag" value="login">
						<a tabindex="5" class="btn btn-link text-muted" onClick="goto_register()">注册</a>
						<a class="btn btn-link text-muted" href="../">首页</a>
						<input class="btn btn-primary" type="submit" tabindex="3" value="登录"
							style="color:white;" />
					</div>
				</form>
			</div>
		
			<!-- 注册页面 -->
			<div class="login sign-up-htm">
				<form action="logOrRig.php" method="post" class="container offset1 loginform">
					<!-- 猫头鹰控件 -->
					<div id="owl-login" class="register-owl">
						<div class="hand"></div>
						<div class="hand hand-r"></div>
						<div class="arms">
							<div class="arm"></div>
							<div class="arm arm-r"></div>
						</div>
					</div>
					<div class="pad input-container">
						<section class="content">
							<span class="input input--hideo">
								<input class="input__field input__field--hideo" type="text" id="register-username"
									autocomplete="off" placeholder="请输入用户名" maxlength="15" name="username"/>
								<label class="input__label input__label--hideo" for="register-username">
									<i class="fa fa-fw fa-user icon icon--hideo"></i>
									<span class="input__label-content input__label-content--hideo"></span>
								</label>
							</span>
							<span class="input input--hideo">
								<input class="input__field input__field--hideo" type="password" id="register-password"
									placeholder="请输入密码" maxlength="15" name="password"/>
								<label class="input__label input__label--hideo" for="register-password">
									<i class="fa fa-fw fa-lock icon icon--hideo"></i>
									<span class="input__label-content input__label-content--hideo"></span>
								</label>
							</span>
							<span class="input input--hideo">
								<input class="input__field input__field--hideo" type="password" id="register-repassword"
									placeholder="请确认密码" maxlength="15" name="passFirm"/>
								<label class="input__label input__label--hideo" for="register-repassword">
									<i class="fa fa-fw fa-lock icon icon--hideo"></i>
									<span class="input__label-content input__label-content--hideo"></span>
								</label>
							</span>
						</section>
					</div>
					<div class="form-actions">
						<input type="hidden" name="flag" value="register">
						<a class="btn pull-left btn-link text-muted" onClick="goto_login()">返回登录</a>
						<input class="btn btn-primary" type="submit" value="注册"
							style="color:white;" />
					</div>
				</form>
			</div>
		</div>
	</div>
</body>

</html>