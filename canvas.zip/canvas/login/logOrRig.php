<?php 
    session_start();
    include '../linkdb.php';
    $flag = $_POST['flag'];

    switch($flag){
        //登录
        case "login" :{

            $username = $_POST['username'];
            $password = md5($_POST['password']);

            if(!empty($username)&&!empty($password)){
                $prepare = $mysqli ->prepare("SELECT `password` FROM `userinfo` WHERE `username`= ? ");
                $prepare->bind_param("s", $username);
                $prepare->execute();                                                                            
                $re = $prepare->get_result();
                $result = $re ->fetch_assoc();
                $prepare->close();
                if(empty($result['password'])){
                    echo <<<EOF
                        <script>
                            window.alert('用户名不存在');
                            location.href='index.php';
                        </script>
EOF;
                }else{
                    if($result['password'] != $password){
                        echo <<<EOF
                            <script>
                                window.alert('密码错误');
                                location.href='index.php';
                            </script>
EOF;
                    }else{
                        $_SESSION['username'] = $username ;
                        echo <<<EOF
                            <script>
                                window.alert('登陆成功');
                                location.href='../info?username=$username';
                            </script>
EOF;
                    }
                }
            }else{
                echo <<<EOF
                <script> 
                    window.alert('账号密码不能为空!');
                    location.href='index.php'; 
                </script>
EOF;
            }  
        }
    break;
    //注册
    case "register":{

        $username = $_POST['username'];
        $password = md5($_POST['password']);
        $firm = md5($_POST['passFirm']);

        if($firm != $password){
            echo <<<EOF
                <script> 
                    window.alert('两次密码不同!');
                    location.href='index.php'; 
                </script>
EOF;
        }

        $prepare = $mysqli->prepare("SELECT `username` FROM `userinfo` WHERE `username`= ? ");
        $prepare->bind_param("s", $username);
        $prepare->execute();
        $re = $prepare ->get_result();
        $result = $re ->fetch_all(MYSQLI_ASSOC);
        $prepare -> close();

        if(empty($result[0])){

            $prepare = $mysqli ->prepare("INSERT INTO `userinfo` (`username`,`password`) VALUES (?,?)");
            $prepare -> bind_param("ss",$username,$password);
            $prepare -> execute();
            $prepare ->close();

            $_SESSION['username'] = $username ;
            echo <<<EOF
                    <script> window.alert('注册成功\\n快来画画吧');
                            location.href='../info?username=$username' 
                    </script>";
EOF;
        }else{
            echo <<<EOF
                <script>
                    window.alert('用户名已被使用\\n换一个吧');
                    location.href='index.php'
                </script>
EOF;
        }
    }
    }
    echo <<<EOF
EOF;
?>
