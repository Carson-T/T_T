<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>展示</title>
    <link rel="stylesheet" href="css/display.css">
</head>

<body>
    <h1>
        <a href="../draw">画布</a>
        <?php
        session_start();
        $username = $_SESSION['username'];
        echo <<<EOF
        <a href="../info?username=$username">个人</a>
EOF;
        ?>
        <a href="../">首页</a>
        <a href="../login">登陆</a>
        <a href="../display">展示</a>
    </h1>
    <div id="display">
        <?php
        include '../linkdb.php';
        $sql = "SELECT * FROM `imginfo` ORDER BY `imgid` DESC";
        $result = $mysqli->query($sql);
        echo '<div id="picdisplay">';
        while ($row = $result->fetch_assoc()) {
            $name = $row['username'];
            $img  = $row['img'];
            $imgid = $row['imgid'];
            $imgname = $row['imgname'];
            if ($imgid == 0) {
                continue;
            }

            echo <<<EOF
                        <div>
                        <a href="../solo/index.php?imgid=$imgid"><img src=$img class="display_img"></a>
                        <p>作者$name 作品名 $imgname</p>
                        </div>
EOF;
        }
        echo '</div>';
        $mysqli->close();
        ?>
    </div>
</body>

</html>