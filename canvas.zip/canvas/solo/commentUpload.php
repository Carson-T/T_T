<?php
    session_start();
    include "../linkdb.php";
    if(empty($_SESSION['username'])){
        echo <<<EOF
            <script>
                alert("请先登录");
                window.location.href="../login";
            </script>
EOF;
    }
    if(empty($_POST['comment'])){
        echo <<<EOF
            <script>
                alert("不能评论空");
                window.location.href="../display"
            </script>
EOF;
    }
    $comment = $_POST['comment'];
    $imgid = $_POST['imgid'];
    $date = date("Y年m月d日 G:i:s");
    $clean_input = htmlspecialchars($comment);
    $prepare = $mysqli->prepare("INSERT INTO `comment` (`imgid`,`username`,`comments`,`date`) VALUE (?,?,?,?)");
    $prepare->bind_param("isss",$imgid,$_SESSION['username'],$clean_input,$date);
    $prepare->execute();
    $prepare->close();
    echo <<<EOF
        <script>
            alert("评论成功");
            window.location.href="index.php?imgid=$imgid";
        </script>
EOF;
?>