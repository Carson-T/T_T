<?php
    session_start();
    include "../linkdb.php";
    $imgid = $_GET['imgid'];
    $username = $_SESSION['username'];
    $prepare = $mysqli ->prepare("SELECT * FROM `imginfo` WHERE imgid = ?");
    $prepare ->bind_param("i",$imgid);
    $prepare ->execute();
    $result = $prepare ->get_result();
    $result = $result ->fetch_all(MYSQLI_ASSOC);
    $prepare ->close();
    if($result[0]['username'] !==$username){
        echo <<<EOF
            <script>
                alert("删除失败");
                window.location.href="../display";
            </script>
EOF;
    }else{
        $prepare = $mysqli ->prepare("DELETE FROM `imginfo` WHERE `imgid` = ?");
        $prepare ->bind_param("i",$imgid);
        $prepare ->execute();
        $prepare= $mysqli->prepare("DELETE FROM `comment` WHERE `imgid` = ?");
        $prepare ->bind_param("i",$imgid);
        $prepare ->execute();
        $prepare ->close();
        echo <<<EOF
            <script>
                alert("删除成功");
                window.location.href="../display";
            </script>
EOF;
    }
?>