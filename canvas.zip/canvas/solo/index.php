<?php
session_start();
if (empty($_GET['imgid'])) {
    header("location:../");
}
echo <<<EOF
        <link rel="stylesheet" href="css/solo.css">
        <h1>
        <a href="../draw">画布</a>
        <a href="../">首页</a>
        <a href="../display">展示</a>
    </h1>

EOF;
include '../linkdb.php';
$s =$_GET['s'];
$imgid = $_GET['imgid'];
$lastimg = $imgid - 1;
$nextimg = $imgid + 1;
$prepare = $mysqli->prepare("SELECT * FROM `imginfo` WHERE `imgid`= ?");
$prepare->bind_param("i", $imgid);
$prepare->execute();
$result = $prepare->get_result();
$result_img = $result->fetch_all(MYSQLI_ASSOC);
if(empty($result_img[0]['img'])){
    $imgid+=$s;
    header("location:../solo/index.php?imgid=$imgid&s=$s");
}
$prepare = $mysqli->prepare("SELECT * FROM `imginfo` WHERE `imgid`<? ");
$prepare->bind_param("i", $imgid);
$prepare->execute();
$result = $prepare->get_result();
$result_lastimg = $result->fetch_all(MYSQLI_ASSOC);


$prepare = $mysqli->prepare("SELECT * FROM `imginfo` WHERE `imgid`>? ");
$prepare->bind_param("i", $imgid);
$prepare->execute();
$result = $prepare->get_result();
$result_nextimg = $result->fetch_all(MYSQLI_ASSOC);

$prepare->close();
$img = $result_img[0]['img'];
$author = $result_img[0]['username'];
$imgname = $result_img[0]['imgname'];
echo <<<EOF
    <div  id="display">
    <img src=$img>
    <p>作品名:$imgname 作者<a href="../info?username=$author"> $author</a>
    EOF;
if ($_SESSION['username'] === $author) {
    echo '<a href="delete.php?imgid='.(string)$imgid.'"style="color:red;">删除这张图</a>';
}
echo '</p>';
if (empty($result_lastimg[0]['img'])) {
    echo "没有上一张啦!";
} else {
    echo <<<EOF
        <a class="change" href="?imgid=$lastimg&s=-1">上一张作品</a>
        EOF;
}
if (empty($result_nextimg[0]['img'])) {
    echo "没有下一张啦!";
} else {
    echo <<<EOF
            <a class="change" href="?imgid=$nextimg&s=1">下一张作品</a>
            EOF;
}
echo <<<EOF
        <p>评论:</p>
        </div>
        <div id="commentForm">
        <form action="commentUpload.php" method="POST">
        <textarea name="comment" placeholder="有啥想说的吗..."></textarea>
        <input type="hidden" name="imgid" value="$imgid"></input>
        <input type="submit" value="提交"></input>
        </form>
        </div>
        EOF;

$prepare = $mysqli->prepare("SELECT * FROM `comment` WHERE `imgid` = ? ORDER BY `id`");
$prepare->bind_param("i", $imgid);
$prepare->execute();
$result = $prepare->get_result();
$result = $result->fetch_all(MYSQLI_ASSOC);
$prepare->close();
foreach ($result as $value) {
    $comment_username = $value['username'];
    $comments = $value['comments'];
    $date = $value['date'];
    echo <<<EOF
            <div style="float:left;clear:both;">
            <p><a href="../info?username=$comment_username" style="font-weight:bold;">$comment_username</a><span style="color:darkgray;font-size:10px;">   $date</span></p>
            <p>$comments</p>
            </div>
EOF;
}
